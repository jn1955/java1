package appl;  

public class Application {	
	
	public static void main(String[] args) {	
		work();
		sleep();
	}
	
	public static void work() {
		System.out.println("Working...");
	}
	
	public static void sleep() {
		System.out.println("Sleeping...");
	}
}
