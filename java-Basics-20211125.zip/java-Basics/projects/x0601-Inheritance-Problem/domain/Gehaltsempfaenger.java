package domain;

public class Gehaltsempfaenger {
	public int nr;
	public String name;
	public double gehalt;
}
