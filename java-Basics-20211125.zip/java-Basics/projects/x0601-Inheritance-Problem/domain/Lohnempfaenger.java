package domain;

public class Lohnempfaenger {
	public int nr;
	public String name;
	public double anzStd;
	public double stdLohn;
}
