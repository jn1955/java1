package appl;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;

public class Application {
	public static void main(String[] args) {
		
		Lohnempfaenger le = new Lohnempfaenger();
		le.nr = 2000;
		le.name = "Mueller";
		le.anzStd = 150;
		le.stdLohn = 20;
		
		Gehaltsempfaenger ge = new Gehaltsempfaenger();
		ge.nr = 3000;
		ge.name = "Schulte";
		ge.gehalt = 4000;

		System.out.println(le.nr);
		System.out.println(le.name);
		System.out.println(le.anzStd);
		System.out.println(le.stdLohn);
		System.out.println();

		System.out.println(ge.nr);
		System.out.println(ge.name);
		System.out.println(ge.gehalt);
		System.out.println();
	}
}
