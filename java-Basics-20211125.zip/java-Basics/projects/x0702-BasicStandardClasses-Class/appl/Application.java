package appl;

import java.lang.reflect.Method;

import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		demoObtainingClass1();
		demoObtainingClass2();
		demoObtainingClass3();
		demoUsingClass();
	}

	public static void demoObtainingClass1() {
		System.out.println("demoObtainingClass1");
		Mitarbeiter m = new Mitarbeiter(1000, "Meier");
		Class<?> cls = m.getClass();
		System.out.println(cls.getName());
		System.out.println(cls.getSimpleName());
	}

	public static void demoObtainingClass2() {
		System.out.println("demoObtainingClass2");
		Class<?> cls = Mitarbeiter.class;
		System.out.println(cls.getName());
		System.out.println(cls.getSimpleName());
	}

	public static void demoObtainingClass3() {
		System.out.println("demoObtainingClass3");
		try {
			Class<?> cls = Class.forName("domain.Mitarbeiter");
			System.out.println(cls.getName());
			System.out.println(cls.getSimpleName());
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void demoUsingClass() {
		System.out.println("demoUsingClass");
		try {
			Class<?> cls = Class.forName("domain.Mitarbeiter");
			for(Method m : cls.getDeclaredMethods()) {
				System.out.println(m.getName());
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
