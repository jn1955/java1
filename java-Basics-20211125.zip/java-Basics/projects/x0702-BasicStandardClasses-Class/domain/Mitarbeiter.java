package domain;

public class Mitarbeiter extends Object {

	private int nr;
	private String name;
	
	public Mitarbeiter(int nr, String name) {
		super();
		this.nr = nr;
		this.name = name;
	}

	public int getNr() {
		return this.nr;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void print() {
		System.out.println(this.nr + " " + this.name);
	}
}
