package appl;

public class Application {
	public static void main(String[] args) {

		// TODO 
		// Array mit 5 double-Elemente erzeugen
		// Methode "durchschnitt" implementieren, die den Durchschnitt
		// von den Elementen dieses double-Arrays berechnet und zur�ckliefert		
	}
}
