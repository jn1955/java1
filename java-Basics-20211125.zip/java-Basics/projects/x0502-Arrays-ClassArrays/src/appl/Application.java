package appl;

import java.util.Arrays;

public class Application {
	public static void main(String[] args) {
		
		int[] numbers = new int[] { 20, 90, 30, 80, 40, 10, 50 };
		
		Arrays.sort(numbers);
		
		for (int number : numbers) 
			System.out.print(number + " ");
		System.out.println();
		
		String s = Arrays.toString(numbers);
		System.out.println(s);
		
		int index1 = Arrays.binarySearch(numbers, 80);
		System.out.println(index1);
		
		int index2 = Arrays.binarySearch(numbers, 77);
		System.out.println(index2);
	}
	
}
