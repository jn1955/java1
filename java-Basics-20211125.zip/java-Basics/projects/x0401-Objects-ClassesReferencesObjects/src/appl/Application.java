package appl; 

public class Application {	
	
	public static void main(String[] args) {
		demoCreation();
		demoAccess();
		demoAssigningPointer();
		demoAssigningState();
		demoNullPointer();
	}
	
	public static void demoCreation() {
		System.out.println("demoCreation");
		Konto k1;
		k1 = new Konto();
		
		Konto k2 = new Konto();
		
		System.out.println(k1);
		System.out.println(k2);
	}

	public static void demoAccess() {
		System.out.println("demoAccess");
		Konto k = new Konto();
		
		System.out.println(k.nr);
		System.out.println(k.kredit);
		System.out.println(k.bestand);
		
		k.nr = 4711;
		k.kredit = 3000.0;
		k.bestand = 4000.0;
		
		System.out.println(k.nr);
		System.out.println(k.kredit);
		System.out.println(k.bestand);
	}

	public static void demoAssigningPointer() {
		System.out.println("demoAssigningPointer");
		
		Konto k1 = new Konto();
		k1.nr = 4711;
		k1.kredit = 3000.0;
		k1.bestand = 4000.0;
		
		Konto k2 = new Konto();
		k2.nr = 4712;
		k2.kredit = 6000.0;
		k2.bestand = 8000.0;
		
		k2 = k1;
		System.out.println(k1 == k2);
		
		k1.bestand = 10000;
		System.out.println(k2.bestand);
	}

	public static void demoAssigningState() {
		System.out.println("demoAssigningState");
		
		Konto k1 = new Konto();
		k1.nr = 4711;
		k1.kredit = 3000.0;
		k1.bestand = 4000.0;
		
		Konto k2 = new Konto();
		k2.nr = 4712;
		k2.kredit = 6000.0;
		k2.bestand = 8000.0;
		
		k2.nr = k1.nr;
		k2.kredit = k1.kredit;
		k2.bestand = k1.bestand;
		
		System.out.println(k1 == k2);

		System.out.println(k1.nr == k2.nr && k1.kredit == k2.kredit && k1.bestand == k2.bestand);

		k1.bestand = 10000;
		System.out.println(k2.bestand);
	}
	
	public static void demoNullPointer() {
		System.out.println("demoNullPointer");
		Konto k = new Konto();
		k.nr = 4711;
		System.out.println(k);
		System.out.println(k.nr);
		System.out.println(k.kredit);
		System.out.println(k.bestand);
		k = null;
		System.out.println(k);
		System.out.println(k.nr);	// NullPointerException
		System.out.println(k.kredit);
		System.out.println(k.bestand);

	}
}
