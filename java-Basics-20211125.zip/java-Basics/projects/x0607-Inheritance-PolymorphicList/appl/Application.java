package appl;

import java.util.ArrayList;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		ArrayList<Mitarbeiter> liste = new ArrayList<>();
		
		liste.add(new Mitarbeiter(1000, "Meier"));
		liste.add(new Lohnempfaenger(2000, "Mueller", 150, 20));
		liste.add(new Gehaltsempfaenger(3000, "Schulte", 4000));

		for (int i = 0; i < liste.size(); i++) {
			Mitarbeiter m = liste.get(i);
			System.out.println(m.nr);
			System.out.println(m.name);
			System.out.println();
		}

//		for (Mitarbeiter m : liste) {
//			System.out.println(m.nr);
//			System.out.println(m.name);
//			System.out.println();
//		}
	}
}
