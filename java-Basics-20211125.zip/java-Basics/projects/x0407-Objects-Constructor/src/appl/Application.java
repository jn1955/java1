package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		// final Konto k1 = new Konto();  // illegal
		Konto k1 = new Konto(4711, 3000.0, 4000.0);
  		// k1.Konto(4799, 3000.0, 4000.0);  // illegal
		k1.print();

		final Konto k2 = new Konto(4712, 6000.0, 8000.0);
		k2.print();
	}
	
}
