package appl;

public class Application {
	public static void main(String[] args) {

		// TODO
		// Implementieren Sie eine Klassenhierarchie der Klassen Figur, Kreis und Rechteck.
		// Jede Figur hat einen Ausgangpunkt: x und y
		// Ein Kreis hat zus�tzlich einen Radius, ein Rechteck hat zus�tzlich eine Breite und eine Hoehe
		
	}
}
