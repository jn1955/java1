package appl; 

public class Application {	
	
	public static void main(String[] args) {	
		demo1();
		demo2();
		demo3();
	}
	
	public static void demo1() {
		System.out.println("demo1");
		printSumOf40And2();
	}
	
	public static void demo2() {
		System.out.println("demo2");
		int alpha = 40;
		int beta = 2;
		
		printSumOf(alpha, beta);
		printSumOf(40, 2);
		printSumOf(38 + 2, 1 + 1);
	}

	public static void demo3() {
		System.out.println("demo3");
		int alpha = 40;
		int beta = 2;
		int result = sumOf(alpha, beta);
		System.out.println(result);
		System.out.println(sumOf(40, 2));
		System.out.println(sumOf(sumOf(35, 5), 2));
	}

	public static void printSumOf40And2() {
		int sum = 40 + 2;
		System.out.println(sum);
	}

	public static void printSumOf(int x, int y) {
		int sum = x + y;
		System.out.println(sum);
	}

	public static int sumOf(int x, int y) {
		int sum = x + y;
		return sum;
	}
}
