package appl; 

public class Application {	
	
	public static void main(String[] args) {
		System.out.println(sum(40, 2));
		System.out.println(sum(20, 30, 2));
		System.out.println(sum(3.0, 0.14));
		System.out.println(sum(1, 2, 0.14));
	}
	
	public static int sum(int x, int y) {
		System.out.println("sum(int, int)");
		return x + y;
	}
	public static int sum(int x, int y, int z) {
		System.out.println("sum(int, int, int)");
		return sum(x, y) + z;
	}
	public static double sum(double x, double y) {
		System.out.println("sum(double, double)");
		return x + y;
	}
	public static double sum(double x, double y, double z) {
		System.out.println("sum(double, double, double)");
		return sum(x, y) + z;
	}
}
