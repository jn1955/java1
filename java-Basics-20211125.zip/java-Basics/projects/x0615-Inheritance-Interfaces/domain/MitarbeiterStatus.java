package domain;

public interface MitarbeiterStatus {
	public abstract void print();
	// void print();
	public abstract double getVerdienst();
	// double getVerdienst();
}
