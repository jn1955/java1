package domain;

public class Mitarbeiter {
	
	private final int nr;
	private String name;
	private MitarbeiterStatus status;
	
	public Mitarbeiter(int nr, String name, MitarbeiterStatus status) {
		this.nr = nr;
		this.name = name;
		this.status = status;
	}
	
	public final int getNr() {
		return this.nr;
	}
	
	public final String getName() {
		return this.name;
	}
	
	public final void setName(String name) {
		this.name = name;
	}
	
	public final MitarbeiterStatus getStatus() {
		return this.status;
	}
	
	public final void setStatus(MitarbeiterStatus status) {
		this.status = status;
	}

	public void print() {
		System.out.println(this.nr);
		System.out.println(this.name);
		this.status.print();
	}
	
	public double getVerdienst() {
		return this.status.getVerdienst();
	}
}
