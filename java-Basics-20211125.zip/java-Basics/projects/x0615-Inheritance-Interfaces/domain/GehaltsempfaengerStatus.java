package domain;

public class GehaltsempfaengerStatus implements MitarbeiterStatus {
	
	private double gehalt;

	public GehaltsempfaengerStatus(double gehalt) {
		this.gehalt = gehalt;
	}

	public final double getGehalt() {
		return this.gehalt;
	}
	
	public final void setGehalt(double gehalt) {
		this.gehalt = gehalt;
	}

	@Override
	public void print() {
		System.out.println(this.gehalt);
	}
	
	@Override
	public double getVerdienst() {
		return this.gehalt;
	}
}
