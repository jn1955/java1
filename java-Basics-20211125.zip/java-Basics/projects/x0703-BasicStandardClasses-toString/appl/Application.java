package appl;

import domain.Mitarbeiter1;
import domain.Mitarbeiter2;

public class Application {
	public static void main(String[] args) {
		demo1();
		demo2();
	}

	public static void demo1() {
		System.out.println("demo1");
		Mitarbeiter1 m = new Mitarbeiter1(1000, "Meier");

		System.out.println(m.toString());
		System.out.println(m);

		Object obj = m;

		System.out.println(obj.toString());
		System.out.println(obj);

		print(obj);
	}

	public static void demo2() {
		System.out.println("demo2");
		Mitarbeiter2 m = new Mitarbeiter2(1000, "Meier");

		System.out.println(m.toString());
		System.out.println(m);

		Object obj = m;

		System.out.println(obj.toString());
		System.out.println(obj);

		print(obj);
	}

	private static void print(Object obj) {
		String s = obj.toString();
		System.out.println(s);
	}
}
