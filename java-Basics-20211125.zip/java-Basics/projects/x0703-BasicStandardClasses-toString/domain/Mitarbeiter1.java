package domain;

public class Mitarbeiter1 {

	private int nr;
	private String name;
	
	public Mitarbeiter1(int nr, String name) {
		this.nr = nr;
		this.name = name;
	}

	public int getNr() {
		return this.nr;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
