package domain;

public class Mitarbeiter2 {

	private int nr;
	private String name;
	
	public Mitarbeiter2(int nr, String name) {
		this.nr = nr;
		this.name = name;
	}

	public int getNr() {
		return this.nr;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.nr + " " + this.name;
	}
}
