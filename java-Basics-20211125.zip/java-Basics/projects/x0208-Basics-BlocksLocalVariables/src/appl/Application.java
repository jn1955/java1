package appl; 

public class Application {	
	
	public static void main(String[] args) {
		demo1();
		demo2();
	}
	
	public static void demo1() {
		double anfangsKaptial = 1000.0;
		double zinssatz = 5.0;
		int laufzeit = 3;

		double kapital = anfangsKaptial;
		double zinsen;
		for(int jahr = 0; jahr < laufzeit; jahr++) {
			zinsen = kapital * zinssatz / 100;
			kapital += zinsen;
		}
		System.out.println("anfangskaptial = " + anfangsKaptial);
		System.out.println("zinssatz       = " + zinssatz);
		System.out.println("laufzeit       = " + anfangsKaptial);
		System.out.println("kapital        = " + kapital);
	}
	
	public static void demo2() {
		double anfangsKaptial = 1000.0;
		double zinssatz = 5.0;
		int laufzeit = 3;

		double kapital = anfangsKaptial;
		for(int jahr = 0; jahr < laufzeit; jahr++) {
			double zinsen = kapital * zinssatz / 100;
			kapital += zinsen;
		}
		System.out.println("anfangskaptial = " + anfangsKaptial);
		System.out.println("zinssatz       = " + zinssatz);
		System.out.println("laufzeit       = " + anfangsKaptial);
		System.out.println("kapital        = " + kapital);
	}
}
