package appl;

public class Application {

	public static void main(String[] args) {
		demoSum();
		demoSumA();
		demoSumB();
	}

	public static void demoSum() {
		System.out.println("demoSum");
		System.out.println(sum(1, 2));
		System.out.println(sum(1, 2, 3));
		System.out.println(sum(1, 2, 3, 4));
		// System.out.println(sum(1, 2, 3, 4, 5)); // illegal
	}

	public static void demoSumA() {
		System.out.println("demoSumA");
		System.out.println(sumA(new int[] { 1, 2 }));
		System.out.println(sumA(new int[] { 1, 2, 3 }));
		System.out.println(sumA(new int[] { 1, 2, 3, 4 }));
	}

	public static void demoSumB() {
		System.out.println("demoSumB");
		System.out.println(sumB(new int[] { 1, 2 }));
		System.out.println(sumB(new int[] { 1, 2, 3 }));
		System.out.println(sumB(new int[] { 1, 2, 3, 4 }));
		System.out.println(sumB(1, 2));
		System.out.println(sumB(1, 2, 3));
		System.out.println(sumB(1, 2, 3, 4));
	}

	static int sum(int arg0, int arg1) {
		return arg0 + arg1;
	}

	static int sum(int arg0, int arg1, int arg2) {
		return arg0 + arg1 + arg2;
	}

	static int sum(int arg0, int arg1, int arg2, int arg3) {
		return arg0 + arg1 + arg2 + arg3;
	}

	static int sumA(int[] args) {
		int sum = 0;
		for (int i = 0; i < args.length; i++) {
			int arg = args[i];
			sum += arg;
		}
		return sum;
	}

	static int sumB(int... args) {
		int sum = 0;
		for (int i = 0; i < args.length; i++) {
			int arg = args[i];
			sum += arg;
		}
		return sum;
	}
}
