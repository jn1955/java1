package appl;

public class Application {
	public static void main(String[] args) {

		KontoList liste = new KontoList(3);

		try {
			liste.add(new Konto(4711, 3000));
			liste.add(new Konto(4712, 4000));
			liste.add(new Konto(4713, 5000));
			liste.add(new Konto(4714, 6000));
		}
		catch (RuntimeException e) {
			System.out.println(e);
		}

		for (int i = 0; i < liste.size(); i++) {
			Konto k = liste.get(i);
			k.print();
		}
	}
}
