package appl;

public class KontoList {

	private Konto[] konten;
	private int kontoCount;
	
	public KontoList(int capacity) {
		this.konten = new Konto[capacity];
	}
	public void add(Konto k) {
		if (this.kontoCount == this.konten.length) {
			throw new RuntimeException("Liste ist voll");
		}
		this.konten[this.kontoCount] = k;
		this.kontoCount++;
	}
	
	public int size() {
		return this.kontoCount;
	}
	
	public Konto get(int index) {
		if (index < 0 || index >= this.kontoCount) {
			throw new RuntimeException("ungueltiger Index");
		}
		return this.konten[index];
	}
}
