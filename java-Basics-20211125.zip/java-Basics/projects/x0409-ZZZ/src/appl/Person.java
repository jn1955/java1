package appl;

public class Person {
	
	// TODO: Preconditions checken...
	
}
