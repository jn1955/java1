package appl;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		Mitarbeiter ma = new Mitarbeiter();
		ma.nr = 1000;
		ma.name = "Meier";
		
		Lohnempfaenger le = new Lohnempfaenger();
		le.ma.nr = 2000;
		le.ma.name = "Mueller";
		le.anzStd = 150;
		le.stdLohn = 20;
		
		Gehaltsempfaenger ge = new Gehaltsempfaenger();
		ge.ma.nr = 3000;
		ge.ma.name = "Schulte";
		ge.gehalt = 4000;

		System.out.println(ma.nr);
		System.out.println(ma.name);
		System.out.println();
		
		System.out.println(le.ma.nr);
		System.out.println(le.ma.name);
		System.out.println(le.anzStd);
		System.out.println(le.stdLohn);
		System.out.println();

		System.out.println(ge.ma.nr);
		System.out.println(ge.ma.name);
		System.out.println(ge.gehalt);
		System.out.println();
	}
}
