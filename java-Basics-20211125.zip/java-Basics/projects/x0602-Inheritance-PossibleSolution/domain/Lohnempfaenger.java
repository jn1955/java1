package domain;

public class Lohnempfaenger {
	public Mitarbeiter ma = new Mitarbeiter();
	public double anzStd;
	public double stdLohn;
}
