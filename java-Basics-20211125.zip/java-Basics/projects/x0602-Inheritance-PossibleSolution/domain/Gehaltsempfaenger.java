package domain;

public class Gehaltsempfaenger {
	public Mitarbeiter ma = new Mitarbeiter();
	public double gehalt;
}
