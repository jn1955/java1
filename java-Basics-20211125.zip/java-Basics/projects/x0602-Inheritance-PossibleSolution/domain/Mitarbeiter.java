package domain;

public class Mitarbeiter {
	public int nr;
	public String name;
}
