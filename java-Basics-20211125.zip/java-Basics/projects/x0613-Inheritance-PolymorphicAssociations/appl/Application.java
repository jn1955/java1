package appl;

import domain.Firma;
import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		Firma firma = new Firma("Siemens");
		firma.addMitarbeiter(new Gehaltsempfaenger(1000, "Meier", 5000));
		firma.addMitarbeiter(new Lohnempfaenger(2000, "Mueller", 150, 20));
		firma.addMitarbeiter(new Gehaltsempfaenger(3000, "Schulte", 4000));

		firma.print();
		
		System.out.println(firma.getGesamtVerdienst());
	}
}
