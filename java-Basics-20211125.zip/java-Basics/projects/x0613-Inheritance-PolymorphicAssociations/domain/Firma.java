package domain;

import java.util.ArrayList;

public class Firma {
	
	private String name;
	private ArrayList<Mitarbeiter> mitarbeiterListe = new ArrayList<>();
	
	public Firma(String name) {
		this.name = name;
	}
	
	public void addMitarbeiter(Mitarbeiter m) {
		if (this.findMitarbeiter(m.getNr()) != null) {
			throw new RuntimeException("Es gibt bereits einen Mitarbeiter mit dieser Nummer");
		}
		this.mitarbeiterListe.add(m);
	}
	
	public int getMitarbeiterCount() {
		return this.mitarbeiterListe.size();
	}
	
	public Mitarbeiter getMitarbeiter(int index) {
		return this.mitarbeiterListe.get(index);
	}
	
	public Mitarbeiter findMitarbeiter(int nr) {
		for (Mitarbeiter m : this.mitarbeiterListe) {
			if (m.getNr() == nr) { 
				return m;
			}
		}
		return null;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void print() {
		System.out.println(this.name);
		System.out.println();
		for (Mitarbeiter m : this.mitarbeiterListe) {
			m.print();
			System.out.println();
		}
	}
	
	public double getGesamtVerdienst() {
		double total = 0;
		for (Mitarbeiter m : this.mitarbeiterListe) {
			total += m.getVerdienst();
		}
		return total;
	}
}
