package domain;

public class Lohnempfaenger extends Mitarbeiter {
	
	private double anzStd;
	private double stdLohn;

	public Lohnempfaenger(int nr, String name, double anzStd, double stdLohn) {
		super(nr, name);
		this.anzStd = anzStd ;
		this.stdLohn = stdLohn;
	}

	public final double getAnzStd() {
		return this.anzStd;
	}
	
	public final void setAnzStd(double anzStd) {
		this.anzStd = anzStd;
	}
	
	public final double getStdLohn() {
		return this.stdLohn;
	}
	
	public final void setStdLohn(double stdLohn) {
		this.stdLohn = stdLohn;
	}
	
	@Override
	public void print() {
		super.print();
		System.out.println(this.anzStd);
		System.out.println(this.stdLohn);
	}
	
	@Override
	public double getVerdienst() {
		return this.anzStd * this.stdLohn;
	}
}
