package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		Konto k1 = new Konto(4711, 3000.0, 4000.0);
		k1.print();

		final Konto k2 = new Konto(4712, 6000.0);
		k2.print();

		final Konto k3 = new Konto(4713);
		k3.print();
	}
	
}
