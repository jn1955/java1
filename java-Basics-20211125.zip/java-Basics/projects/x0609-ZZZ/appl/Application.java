package appl;

public class Application {
	public static void main(String[] args) {
		
		// TODO
		// Berechnen Sie den Gesamntumfang aller in der ArrayList gespeicherten Figuren
		// Geben Sie alle Figuren aus.
	}
}
