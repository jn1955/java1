package appl;

public class Application {
	public static void main(String[] args) {
		demoEquals();
		demoSplit();
		demoIntConversion();
		demoDoubleConversion();
	}

	public static void demoEquals() {
		System.out.println("demoEquals");
		String s1 = "Hello";
		String s2 = "Hello";
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));

		String s3 = "Wo";
		s3 += "rld";
		String s4 = "World";
		System.out.println(s3 == s4);
		System.out.println(s3.equals(s4));
	}


	public static void demoSplit() {
		System.out.println("demoSplit");
		String s1 = "Gl�ck,Glanz,Ruhm";
		String[] tokens1 = s1.split(",");
		for (String token : tokens1) {
			System.out.println(token);
		}

		String s2 = "java.lang.String";
		String[] tokens2 = s2.split("\\.");
		for (String token : tokens2) {
			System.out.println(token);
		}
	}

	public static void demoIntConversion() {
		System.out.println("demoIntConversion");
		int i1 = 42;
		String si = String.valueOf(i1);
		System.out.println(si);
		int i2 = Integer.parseInt(si);
		System.out.println(i2);
		try {
			int v = Integer.parseInt("1a");
			System.out.println(v);
		}
		catch (RuntimeException e) {
			System.out.println(e);
		}

	}

	public static void demoDoubleConversion() {
		System.out.println("demoDoubleConversion");
		double d1 = 3.14;
		String sd = String.valueOf(d1);
		System.out.println(sd);
		double d2 = Double.parseDouble(sd);
		System.out.println(d2);
		try {
			double v = Double.parseDouble("1.2a");
			System.out.println(v);
		}
		catch (RuntimeException e) {
			System.out.println(e);
		}
	}
}
