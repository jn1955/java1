package domain;

public class Gehaltsempfaenger extends Mitarbeiter {
	
	public double gehalt;

	public Gehaltsempfaenger(int nr, String name, double gehalt) {
		super(nr, name);
		this.gehalt = gehalt;
	}
}
