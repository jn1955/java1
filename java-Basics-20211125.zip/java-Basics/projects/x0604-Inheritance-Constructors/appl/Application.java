package appl;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		Mitarbeiter ma = new Mitarbeiter(1000, "Meier");
		Lohnempfaenger le = new Lohnempfaenger(2000, "Mueller", 150, 20);
		Gehaltsempfaenger ge = new Gehaltsempfaenger(3000, "Schulte", 4000);

		System.out.println(ma.nr);
		System.out.println(ma.name);
		System.out.println();
		
		System.out.println(le.nr);
		System.out.println(le.name);
		System.out.println(le.anzStd);
		System.out.println(le.stdLohn);
		System.out.println();

		System.out.println(ge.nr);
		System.out.println(ge.name);
		System.out.println(ge.gehalt);
		System.out.println();
	}
}
