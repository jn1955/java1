package appl;

public interface Y {
	public abstract void h();
}
