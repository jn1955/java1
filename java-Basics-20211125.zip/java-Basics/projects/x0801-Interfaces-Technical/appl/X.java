package appl;

public interface X {
	public abstract void f();
	public abstract void g();
}
