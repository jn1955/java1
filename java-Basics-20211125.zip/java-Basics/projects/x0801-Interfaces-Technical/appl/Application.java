package appl;


public class Application {
	public static void main(String[] args) {
		B b = new B();
		tuWasMitEinemB(b);
		A a = b;
		tuWasMitEinemA(a);
		X x = b;
		tuWasMitEinemX(x);
		Y y = b;
		tuWasMitEinemY(y);
	}

	private static void tuWasMitEinemB(B b) {
		System.out.println(b.i);
		System.out.println(b.j);
		b.fi();
		b.fj();
		b.f();
		b.g();
		b.h();
		System.out.println();
	}

	private static void tuWasMitEinemA(A a) {
		System.out.println(a.i);
		a.fi();
		System.out.println();
	}

	private static void tuWasMitEinemX(X x) {
		x.f();
		x.g();
		System.out.println();
	}

	private static void tuWasMitEinemY(Y y) {
		y.h();
		System.out.println();
	}
}
