package appl;

public class A {
	public int i = 77;
	public void fi() {
		System.out.println(this.i);
	}
}
