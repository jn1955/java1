package appl;

public class B extends A implements X, Y {
	public int j = 88;
	public void fj() {
		System.out.println(this.j);
	}
	@Override
	public void f() {
		System.out.println("B.f()");
	}
	@Override
	public void g() {
		System.out.println("B.g()");
	}
	@Override
	public void h() {
		System.out.println("B.h()");
	}
}
