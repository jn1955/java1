package appl;

public class Application {
	public static void main(String[] args) {

		Konto[] konten = new Konto[5];
		int kontoCount = 0;
		
		konten[kontoCount] = new Konto(4711, 3000);
		kontoCount++;
		konten[kontoCount] = new Konto(4712, 4000);
		kontoCount++;
		konten[kontoCount] = new Konto(4713, 5000);
		kontoCount++;
		
		for (int i = 0; i < kontoCount; i++) {
			Konto k = konten[i];
			k.print();
		}
		System.out.println();

		konten[0].einzahlen(1000);
		konten[1].einzahlen(2000);
		
		for (int i = 0; i < kontoCount; i++) {
			konten[i].print();
		}
		System.out.println();
		
		double total = 0;
		for (Konto k : konten) {
			if (k == null) {
				break;
			}
			total += k.getBestand();
		}
		System.out.println(total);
	}
}
