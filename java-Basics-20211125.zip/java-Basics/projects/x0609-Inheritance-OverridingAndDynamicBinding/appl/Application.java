package appl;

import java.util.ArrayList;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		ArrayList<Mitarbeiter> liste = new ArrayList<>();

		liste.add(new Mitarbeiter(1000, "Meier"));
		liste.add(new Lohnempfaenger(2000, "Mueller", 150, 20));
		liste.add(new Gehaltsempfaenger(3000, "Schulte", 4000));

		for (Mitarbeiter m : liste) {
			m.print(); // ????????
			System.out.println();
		}
		
		double gesamtVerdienst = 0;
		for (Mitarbeiter m : liste) {
			gesamtVerdienst += m.getVerdienst(); // ????????
		}
		System.out.println(gesamtVerdienst);
	}
}
