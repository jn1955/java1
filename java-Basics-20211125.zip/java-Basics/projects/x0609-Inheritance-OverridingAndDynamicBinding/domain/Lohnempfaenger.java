package domain;

public class Lohnempfaenger extends Mitarbeiter {
	
	public double anzStd;
	public double stdLohn;

	public Lohnempfaenger(int nr, String name, double anzStd, double stdLohn) {
		super(nr, name);
		this.anzStd = anzStd ;
		this.stdLohn = stdLohn;
	}

	@Override
	public void print() {
		super.print();
		// System.out.println(this.nr);
		// System.out.println(this.name);
		System.out.println(this.anzStd);
		System.out.println(this.stdLohn);
	}
	
	@Override
	public double getVerdienst() {
		return this.anzStd * this.stdLohn;
	}
}
