package domain;

public class Gehaltsempfaenger extends Mitarbeiter {
	
	public double gehalt;

	public Gehaltsempfaenger(int nr, String name, double gehalt) {
		super(nr, name);
		this.gehalt = gehalt;
	}

	@Override
	public void print() {
		super.print();
		// System.out.println(this.nr);
		// System.out.println(this.name);
		System.out.println(this.gehalt);
	}
	
	@Override
	public double getVerdienst() {
		return this.gehalt;
	}
}
