package domain;

public class Mitarbeiter {
	
	public int nr;
	public String name;
	
	public Mitarbeiter(int nr, String name) {
		this.nr = nr;
		this.name = name;
	}
	
	public void print() {
		System.out.println(this.nr);
		System.out.println(this.name);
	}
	
	public double getVerdienst() {
		return 0; // Verlegenheitsloesung!
	}
}
