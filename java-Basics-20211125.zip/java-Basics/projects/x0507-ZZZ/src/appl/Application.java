package appl;

public class Application {
	public static void main(String[] args) {
		// TODO
		// Eine ArrayList<String> erzeugen
		// Strings hinzuf�gen
		// Methoden ausprobieren:
		// size, get, contains, indexOf, remove, ...
	}
	
}
