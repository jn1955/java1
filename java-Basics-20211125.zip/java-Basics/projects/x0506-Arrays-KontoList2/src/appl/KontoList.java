package appl;

public class KontoList {

	private Konto[] konten;
	private int kontoCount;
	
	public KontoList(int capacity) {
		this.konten = new Konto[capacity];
	}
	public KontoList() {
		this(2);
	}
	public void add(Konto k) {
		if (this.kontoCount == this.konten.length) {
			Konto[] neueKonten = new Konto[this.konten.length * 2];
			for (int i = 0; i < this.konten.length; i++) {
				neueKonten[i] = this.konten[i];
			}
			this.konten = neueKonten;
		}
		this.konten[this.kontoCount] = k;
		this.kontoCount++;
	}
	
	public int size() {
		return this.kontoCount;
	}
	
	public Konto get(int index) {
		if (index < 0 || index >= this.kontoCount) {
			throw new RuntimeException("ungueltiger Index");
		}
		return this.konten[index];
	}
}
