package appl; 

public class Application {	
	
	public static void main(String[] args) {	
		demoIf();
		demoIfElse();
		demoWhile();
		demoFor();
		demoWithoutBocks();
	}
	
	public static void demoIf() {
		System.out.println("demoIf");
		int alpha = 42;
		if (alpha == 42) {
			System.out.println("im then-Zweig");
			System.out.println("alpha hat den Wert 42");
		}
	}
	
	public static void demoIfElse() {
		System.out.println("demoIfElse");
		int alpha = 77;
		if (alpha == 42) {
			System.out.println("alpha hat den Wert 42");
		}
		else {
			System.out.println("alpha hat einen anderen Wert als 42");
		}
	}

	public static void demoWhile() {
		System.out.println("demoWhile");
		int counter = 0;
		while(counter < 5) {
			System.out.println(counter);
			counter++;
		}
		System.out.println("Counter nach Verlassen der Schleife: " + counter);
	}

	public static void demoFor() {
		System.out.println("demoFor");
		for(int counter = 0; counter < 5; counter++) {
			System.out.println(counter);
		}
		// System.out.println("Counter nach Verlassen der Schleife: " + counter);
		// counter ist nicht mehr sichtbar (existiert nicht mehr)
	}

	public static void demoWithoutBocks() {
		System.out.println("demoWithoutBocks");
		int alpha = 42;
		if (alpha == 42) 
			System.out.println("alpha hat den Wert 42");
		for(int counter = 0; counter < 5; counter++) 
			System.out.println(counter);
		
		// Besser IMMER Bl�cke bauen...
	}
}
