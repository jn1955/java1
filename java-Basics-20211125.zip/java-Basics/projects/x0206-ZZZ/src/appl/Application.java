package appl; 

public class Application {	
	
	public static void main(String[] args) {
		int x = 77;
		int y = 33;
		
		// TODO...
		
		System.out.println("GGT = ");  // GGT = 11
	}
	
}
