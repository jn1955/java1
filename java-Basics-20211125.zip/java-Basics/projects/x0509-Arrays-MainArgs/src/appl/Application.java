package appl;


public class Application  {
	public static void main(String[] args) {
		System.out.println("Anzahl Argumente: " + args.length);
		if (args.length > 0) {
			System.out.println("Argumente:");
			for (int i = 0; i < args.length; i++) {
				System.out.println(i + ": " + args[i]);
			}
            System.out.println("Argumente noch einmal:");
            for (String arg : args) {
				System.out.println(arg);
			}
		}
	}
}

