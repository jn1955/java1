package appl; 

public class Application {	
	
	public static void main(String[] args) {
		System.out.println(Math.ggt(77, 33));
		System.out.println(Math.kgv(77, 33));
	}
	
}
