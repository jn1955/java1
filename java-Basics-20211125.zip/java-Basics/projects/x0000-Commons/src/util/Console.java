package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

// Die Seminarteilnehmer sollen diese Klasse nur nutzen k�nnen -
// sie k�nnen die Klasse an dieser Stelle nat�rlich noch nicht verstehen!

public class Console {
	private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	public static String readString(String prompt) {
		if (prompt != null) {
			System.out.print(prompt + " ");
		}
		try {
			return reader.readLine();
		}
		catch(IOException e) {
			throw new RuntimeException(e);
		}
	}
	public static String readString() {
		return readString(null);
	}
	public static int readInt(String prompt) {
		while (true) {
			try {
				String s = readString(prompt);
				return Integer.parseInt(s);
			}
			catch(Exception e) {
				System.out.println("input must be int. retry...");
			}
		}
	}
	public static int readInt() {
		return readInt(null);
	}
	public static double readDouble(String prompt) {
		while (true) {
			try {
				String s = readString(prompt);
				return Double.parseDouble(s);
			}
			catch(Exception e) {
				System.out.println("input must be double. retry...");
			}
		}
	}
	public static double readDouble() {
		return readDouble(null);
	}
	public static char readChar(String prompt) {
		while (true) {
			String s = readString(prompt);
			if (s.length() == 1)
				return s.charAt(0);
			System.out.println("input must be char. retry...");
		}
	}
	public static char readChar() {
		return readChar(null);
	}
}
