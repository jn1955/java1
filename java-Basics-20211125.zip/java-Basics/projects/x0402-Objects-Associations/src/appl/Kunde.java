package appl;

public class Kunde {
	public int nr;
	public String name;
}
