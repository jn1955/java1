package appl;

public class Konto { // Bauplan f�r Konto-Objekte; Benutzerdefinierter Datentyp
	public int nr;
	public double kredit;
	public double bestand;
	public Kunde kd; // Pointer to Kunde
}
