package appl; 

public class Application {	
	
	public static void main(String[] args) {
		Kunde ku = new Kunde();
		ku.nr = 1000;
		ku.name = "Meier";
		
		Konto ko = new Konto();
		ko.nr = 4711;
		ko.kredit = 3000;
		ko.bestand = 4000;
		ko.kd = ku;

		System.out.println(ko);
		System.out.println(ko.nr);
		System.out.println(ko.kredit);
		System.out.println(ko.bestand);
		System.out.println(ko.kd);
		System.out.println(ko.kd.nr);
		System.out.println(ko.kd.name);
		
		// ku = ko; // illegal
	}
}
