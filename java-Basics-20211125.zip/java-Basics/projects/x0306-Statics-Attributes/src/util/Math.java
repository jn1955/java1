package util;

public class Math {
	
	public static int counter = 0;
	
	public static int ggt(int x, int y) {
		counter++;
		while (x != y) {
			if (x > y) {
				x -= y;
			}
			else {
				y -= x;
			}
		}
		return x;
	}

	public static int kgv(int x, int y) {
		counter++;
		int a = x;
		int b = y;
		while (a != b) {
			if (a < b) {
				a += x;
			}
			else {
				b += y;
			}
		}
		return a;
	}
}
