package appl;

import util.Math;

public class Application {	
	
	public static void main(String[] args) {
		System.out.println(Math.ggt(77, 33));
		System.out.println(Math.kgv(77, 33));
		// Math.counter = 1000;
		System.out.println(Math.counter);
	}
	
}
