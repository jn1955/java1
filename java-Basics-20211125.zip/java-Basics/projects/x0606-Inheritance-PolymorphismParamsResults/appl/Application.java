package appl;

import util.Console;
import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		Mitarbeiter m = createMitarbeiter();
		System.out.println();
		printMitarbeiter(m);
	}
	
	public static Mitarbeiter createMitarbeiter() {
		Mitarbeiter m;
		String prompt = "0: Mitarbeiter / 1: Lohnempfaenger / 2: Gehaltsempfaenger ";
		int type = Console.readInt(prompt);
		while (type < 0 || type > 2) {
			System.out.println("bad type. retry...");
			type = Console.readInt(prompt);
		}
		int nr = Console.readInt("nr:");
		String name = Console.readString("name:");
		if (type == 0) {
			m = new Mitarbeiter(nr, name);
		}
		else if (type == 1) {
			double anzStd = Console.readDouble("anzStd:");
			double stdLohn = Console.readDouble("stdLohn:");
			m = new Lohnempfaenger(nr, name, anzStd, stdLohn);
		}
		else if (type == 2) {
			double gehalt = Console.readDouble("gehalt:");
			m = new Gehaltsempfaenger(nr, name, gehalt);
		}
		else
			throw new RuntimeException("this should never happen");
		return m;
	}
	
	public static void printMitarbeiter(Mitarbeiter m) {
		System.out.println(m.nr);
		System.out.println(m.name);
	}
}
