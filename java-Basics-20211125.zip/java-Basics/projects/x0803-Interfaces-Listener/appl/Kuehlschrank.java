package appl;

public class Kuehlschrank implements ThermostatListener {
	@Override
	public void minAlarm() {
		System.out.println("Kuehlung aus");
	}
	@Override
	public void maxAlarm() {
		System.out.println("Kuehlung ein");
	}
}
