package appl;

public class Heizung implements ThermostatListener {
	@Override
	public void minAlarm() {
		System.out.println("Brenner ein");
	}
	@Override
	public void maxAlarm() {
		System.out.println("Brenner aus");
	}
}
