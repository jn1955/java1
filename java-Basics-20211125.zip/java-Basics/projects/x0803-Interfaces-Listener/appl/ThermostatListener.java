package appl;

public interface ThermostatListener {
	public abstract void minAlarm();
	public abstract void maxAlarm();
}
