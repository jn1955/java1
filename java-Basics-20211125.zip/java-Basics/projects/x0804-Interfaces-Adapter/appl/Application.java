package appl;

import heiz.Heizung;
import kuehl.Kuehlschrank;
import term.Thermostat;

public class Application {
	public static void main(String[] args) {
		
		new Thermostat(new ThermostatHeizungAdapter(new Heizung())).run();
		
//		Kuehlschrank k = new Kuehlschrank();
//		Thermostat t2 = new Thermostat(k); 
//		t2.run();
	}
}
