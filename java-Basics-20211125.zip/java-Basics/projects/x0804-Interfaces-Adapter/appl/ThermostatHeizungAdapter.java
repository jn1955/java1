package appl;

import heiz.Heizung;
import term.ThermostatListener;

public class ThermostatHeizungAdapter implements ThermostatListener {

	private Heizung h;
	
	public ThermostatHeizungAdapter(Heizung h) {
		this.h = h;
	}

	@Override
	public void minAlarm() {
		this.h.brennerEin();
	}

	@Override
	public void maxAlarm() {
		this.h.brennerAus();
	}

}
