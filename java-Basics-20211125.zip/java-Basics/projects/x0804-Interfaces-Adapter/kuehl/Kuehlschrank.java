package kuehl;

public class Kuehlschrank {
	public void kuehlungAus() {
		System.out.println("Kuehlung aus");
	}
	public void kuehlungEin() {
		System.out.println("Kuehlung ein");
	}
}
