package term;

public class Thermostat {
	private ThermostatListener listener;
	
	public Thermostat(ThermostatListener listener) {
		this.listener = listener;
	}
	
	public void run() {
		// es ist zu kalt geworden...
		this.listener.minAlarm();
		// es ist zu warm geworden...
		this.listener.maxAlarm();
	}
}
