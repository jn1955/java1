package appl;

import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.List;
import java.awt.TextField;

public class Application {
	public static void main(String[] args) {
		
		// TODO
		// Analysieren Sie folgende Applikation
		// Worin liegen die �hnlichkeiten dieser Anwendung zur Firma-Anwendung?
		// Leider kann man die Anwendung nicht schlie�en. Schiessen Sie es ab!

		Frame frame = new Frame("Mein erstes Fenster");
		frame.setBounds(100, 100, 700, 150);
		frame.setLayout(new FlowLayout());
		frame.setFont(new Font("Arial", Font.PLAIN, 20));
		
		TextField textField = new TextField(10);
		textField.setText("Hello");
		Button button = new Button("Drueck mich");
		List checkBox = new List(3);
		checkBox.add("red");
		checkBox.add("green");
		checkBox.add("blue");
		
		frame.add(checkBox);
		frame.add(button);
		frame.add(textField);
		
		frame.setVisible(true);
		
		for(int i = 0; i < frame.getComponentCount(); i++) {
			Component c = frame.getComponent(i);
			System.out.println(c.getX() + " " + c.getY());
			c.setBackground(Color.yellow);
		}
	}
}
