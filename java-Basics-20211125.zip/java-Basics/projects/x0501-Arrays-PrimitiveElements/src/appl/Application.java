package appl;

public class Application {
	public static void main(String[] args) {
		demo1();
		demo2();
		demo3();
		demo4();
	}
	
	public static void demo1() {
		System.out.println("demo1");
		int[] numbers = new int[4];
		for (int i = 0; i < numbers.length; i++) {
			int number = numbers[i];
			System.out.print(number + " ");
		}
		System.out.println();
		numbers[0] = 20;
		numbers[1] = 30;
		numbers[2] = 40;
		numbers[3] = 50;
		for (int i = 0; i < numbers.length; i++) {
			int number = numbers[i];
			System.out.print(number + " ");
		}
		System.out.println();
	}
	
	public static void demo2() {
		System.out.println("demo2");
		int[] numbers = new int[4];
		for (int number : numbers) {
			System.out.print(number + " ");
		}
		System.out.println();
		numbers[0] = 20;
		numbers[1] = 30;
		numbers[2] = 40;
		numbers[3] = 50;
		for (int number : numbers) {
			System.out.print(number + " ");
		}
		System.out.println();
	}

	public static void demo3() {
		System.out.println("demo3");
		int[] numbers = new int[] { 20, 30, 40, 50 };
		for (int number : numbers) {
			System.out.print(number + " ");
		}
		System.out.println();
	}
	
	public static void demo4() {
		System.out.println("demo4");
		int[] numbers = new int[4];
		numbers[0] = 20;
		numbers[1] = 30;
		numbers[2] = 40;
		numbers[3] = 50;
		print(numbers);
		System.out.println(sum(numbers));
	}

	private static void print(int[] array) {
		for (int i = 0; i < array.length; i++) {
			int element = array[i];
			System.out.print(element + " ");
		}
		System.out.println();
	}

	private static int sum(int[] array) {
		int s = 0;
		for (int element : array) {
			s += element;
		}
		return s;
	}
}
