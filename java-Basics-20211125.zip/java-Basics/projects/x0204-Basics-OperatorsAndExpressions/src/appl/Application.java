package appl; 

public class Application {	
	
	public static void main(String[] args) {	
		demoNumeric();
		demoNumericSpecials();
		demoComparison();
		demoLogical();
	}
	
	public static void demoNumeric() {
		System.out.println("demoNumeric");
		int alpha = 42;
		int beta = 77;
		System.out.println(alpha + beta);
		System.out.println(alpha - beta);
		System.out.println(alpha * beta);
		System.out.println(alpha / beta);
		System.out.println(alpha % beta);
		System.out.println(alpha / (double)beta);
	}
	
	public static void demoNumericSpecials() {
		System.out.println("demoNumericSpecials");
		int alpha = 42;
		int beta = 77;
		
		alpha = alpha + 1;
		System.out.println(alpha);		
		alpha++;
		System.out.println(alpha);		
		++alpha;
		System.out.println(alpha);
		// dito f�r -
		
		beta = beta * 2;
		System.out.println(beta);
		beta *= 2;
		System.out.println(beta);
		beta /= 2;
		System.out.println(beta);
	}

	public static void demoComparison() {
		System.out.println("demoComparison");
		int alpha = 42;
		int beta = 77;
		System.out.println(alpha == beta);
		System.out.println(alpha != beta);
		System.out.println(alpha > beta);
		System.out.println(alpha >= beta);
		System.out.println(alpha < beta);
		System.out.println(alpha <= beta);
	}

	public static void demoLogical() {
		System.out.println("demoLogical");
		boolean alpha = true;
		boolean beta = false;
		System.out.println(alpha && beta);
		System.out.println(alpha || beta);
		System.out.println(! alpha);
		System.out.println(! beta);
	}
}
