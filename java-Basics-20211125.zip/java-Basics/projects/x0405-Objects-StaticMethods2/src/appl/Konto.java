package appl;

public class Konto { 
	public int nr;
	public double kredit;
	public double bestand;

	public static void print(Konto k) {
		System.out.println(k.nr + " " + k.kredit + " " + k.bestand);
	}

	public static void init(Konto k, int nr, double kredit, double bestand) {
		k.nr = nr;
		k.kredit = kredit;
		k.bestand = bestand;
	}

	public static void einzahlen(Konto k, double betrag) {
		k.bestand += betrag;
	}

	public static void auszahlen(Konto k, double betrag) {
		k.bestand -= betrag;
	}

}
