package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		final Konto k1 = new Konto();
		Konto.init(k1, 4711, 3000.0, 4000.0);
		Konto.print(k1);
		Konto.einzahlen(k1, 500.0);
		Konto.print(k1);

		final Konto k2 = new Konto();
		Konto.init(k2, 4712, 6000.0, 8000.0);
		Konto.print(k2);
		Konto.auszahlen(k2, 500.0);
		Konto.print(k2);
	}
	
}
