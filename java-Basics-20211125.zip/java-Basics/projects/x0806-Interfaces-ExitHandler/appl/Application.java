package appl;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;

public class Application {
	public static void main(String[] args) {
		Frame frame = new Frame("Mein Exit-Frame");
		frame.setBounds(100, 100, 400, 200);
		frame.setLayout(new FlowLayout());
		frame.setFont(new Font("Arial", Font.PLAIN, 20));

		Button exitButton = new Button("Exit");
		frame.add(exitButton);
		
		exitButton.addActionListener(new ExitHandler());
		frame.setVisible(true);
	}
}
