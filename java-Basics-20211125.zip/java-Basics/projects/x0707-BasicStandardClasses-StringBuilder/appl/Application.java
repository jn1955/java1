package appl;

public class Application {

	final static int N = 10_000;
	final static String TEXT = "Hello World";

	public static void main(String[] args) {
		demoStringConcatenation();
		demoStringBuilder();
	}

	public static void demoStringConcatenation() {
		System.out.println("demoStringConcatenation");
		long begin = System.currentTimeMillis();
		String s = "";
		for (int i = 0; i < N; i++)
			s += TEXT;
		long end = System.currentTimeMillis();
		System.out.println(s.length() == N * TEXT.length());
		System.out.println(end - begin);
	}

	public static void demoStringBuilder() {
		System.out.println("demoStringBuilder");
		long begin = System.currentTimeMillis();
		StringBuilder buf = new StringBuilder();
		for (int i = 0; i < N; i++)
			buf.append(TEXT);
		String s = buf.toString();
		long end = System.currentTimeMillis();
		System.out.println(s.length() == N * TEXT.length());
		System.out.println(end - begin);
	}
}
