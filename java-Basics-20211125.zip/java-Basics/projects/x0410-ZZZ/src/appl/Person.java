package appl;

public class Person {
	
	// TODO: getter und setter einbauen
	// TODO: isMaennlich und isWeiblich implementieren
	// TODO: isVerheiratet implementieren
	
}
