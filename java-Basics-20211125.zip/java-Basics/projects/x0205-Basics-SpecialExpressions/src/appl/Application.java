package appl; 

public class Application {	
	
	public static void main(String[] args) {	
		demoPostfixPlusPlus();
		demoPrefixPlusPlus();
		demoForbiddenPlusPlus();
		demoConditionalExpression();
		demoForbiddenConditionalExpression();
	}
	
	public static void demoPostfixPlusPlus() {
		System.out.println("demoPostfixPlusPlus");
		int alpha = 42;
		int beta = alpha++;
		System.out.println(alpha);
		System.out.println(beta);
	}
	
	public static void demoPrefixPlusPlus() {
		System.out.println("demoPrefixPlusPlus");
		int alpha = 42;
		int beta = ++alpha;
		System.out.println(alpha);
		System.out.println(beta);
	}

	public static void demoForbiddenPlusPlus() {
		System.out.println("demoForbiddenPlusPlus");
		int alpha = 42;
		int beta = alpha++ + ++alpha;
		System.out.println(alpha);
		System.out.println(beta);
	}

	public static void demoConditionalExpression() {
		System.out.println("demoConditionalExpression");
		int alpha = 42;
		int beta = 77;
		int min = alpha < beta ? alpha : beta;
		System.out.println(min);
	}

	public static void demoForbiddenConditionalExpression() {
		System.out.println("demoForbiddenConditionalExpression");
		int unfug = 3 < 4 ? 5 > 6 ? 7 : 8 : 9;
		System.out.println(unfug);
	}
}
