package appl;

import java.util.ArrayList;

import domain.Mitarbeiter1;
import domain.Mitarbeiter2;

public class Application {
	public static void main(String[] args) {
		demo1();
		demo2();
	}

	static void demo1() {
		System.out.println("demo1");
		ArrayList<Mitarbeiter1> liste = new ArrayList<>();

		liste.add(new Mitarbeiter1(1000, "Meier"));
		liste.add(new Mitarbeiter1(2000, "Mueller"));
		liste.add(new Mitarbeiter1(3000, "Schulte"));

		int index = liste.indexOf(new Mitarbeiter1(2000));
		if (index == -1)
			System.out.println("not found");
		else
			System.out.println(liste.get(index));
		System.out.println(liste.contains(new Mitarbeiter1(2000)));
		System.out.println();
	}

	static void demo2() {
		System.out.println("demo2");
		ArrayList<Mitarbeiter2> liste = new ArrayList<>();

		liste.add(new Mitarbeiter2(1000, "Meier"));
		liste.add(new Mitarbeiter2(2000, "Mueller"));
		liste.add(new Mitarbeiter2(3000, "Schulte"));

		int index = liste.indexOf(new Mitarbeiter2(2000));
		if (index == -1)
			System.out.println("not found");
		else
			System.out.println(liste.get(index));
		System.out.println(liste.contains(new Mitarbeiter2(2000)));
		System.out.println();
	}
}
