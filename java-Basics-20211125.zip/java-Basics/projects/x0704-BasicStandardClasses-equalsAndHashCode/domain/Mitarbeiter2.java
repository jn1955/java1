package domain;

import java.util.Objects;

public class Mitarbeiter2 {

	private int nr;
	private String name;
	
	public Mitarbeiter2(int nr) {
		this(nr, null);
	}

	public Mitarbeiter2(int nr, String name) {
		this.nr = nr;
		this.name = name;
	}

	public int getNr() {
		return this.nr;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.nr + " " + this.name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nr);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mitarbeiter2 other = (Mitarbeiter2) obj;
		return nr == other.nr;
	}
}

