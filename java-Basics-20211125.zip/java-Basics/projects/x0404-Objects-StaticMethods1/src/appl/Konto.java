package appl;

public class Konto { 
	public int nr;
	public double kredit;
	public double bestand;
}
