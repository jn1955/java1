package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		final Konto k1 = new Konto();
		init(k1, 4711, 3000.0, 4000.0);
		print(k1);
		einzahlen(k1, 500.0);
		print(k1);

		final Konto k2 = new Konto();
		init(k2, 4712, 6000.0, 8000.0);
		print(k2);
		auszahlen(k2, 500.0);
		print(k2);
	}
	
	public static void print(Konto k) {
		System.out.println(k.nr + " " + k.kredit + " " + k.bestand);
	}

	public static void init(Konto k, int nr, double kredit, double bestand) {
		k.nr = nr;
		k.kredit = kredit;
		k.bestand = bestand;
	}

	public static void einzahlen(Konto k, double betrag) {
		k.bestand += betrag;
	}

	public static void auszahlen(Konto k, double betrag) {
		k.bestand -= betrag;
	}
}
