package appl;

import util.Math;

public class Application {	
	
	public static void main(String[] args) {
		//Math.PI = 2.71;
		//System.out.println(Math.calculatePI());
		System.out.println(Math.PI);
		System.out.println(java.lang.Math.PI);
	}
	
}
