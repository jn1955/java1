package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		Konto k = new Konto(4711, 3000.0, 4000.0);
		k.print();
		// System.out.println(k.nr);  // illegal
		System.out.println(k.getNr());
		System.out.println(k.getBestand());
		System.out.println(k.getKredit());
		System.out.println(k.getVerfuegbar());
		System.out.println(k.isVerfuegbar(7000.0));
		System.out.println(k.isVerfuegbar(8000.0));
	}
	
}
