package appl;

import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		Class<?> cls = Mitarbeiter.class;
		
		// TODO: Testen Sie die Class-Methoden getDeclaringFields und getConstructors
		// TODO: Worin liegt der Unterschied zwischen get... und getDeclaring...?
	}
}
