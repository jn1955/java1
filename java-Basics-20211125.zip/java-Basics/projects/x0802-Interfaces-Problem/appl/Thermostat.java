package appl;

public class Thermostat {
	private Heizung heizung;
	
	public Thermostat(Heizung heizung) {
		this.heizung = heizung;
	}
	
	public void run() {
		// es ist zu kalt geworden...
		this.heizung.brennerEin();
		// es ist zu warm geworden...
		this.heizung.brennerAus();
	}
}
