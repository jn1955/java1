package appl;


public class Application {
	public static void main(String[] args) {
		
		Heizung h = new Heizung();
		Thermostat t1 = new Thermostat(h);
		t1.run();
		
		Kuehlschrank k = new Kuehlschrank();
		// Thermostat t2 = new Thermostat(k); // geht leider nicht...
	}
}
