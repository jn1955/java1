package appl;

public class Heizung {
	public void brennerEin() {
		System.out.println("Brenner ein");
	}
	public void brennerAus() {
		System.out.println("Brenner aus");
	}
}
