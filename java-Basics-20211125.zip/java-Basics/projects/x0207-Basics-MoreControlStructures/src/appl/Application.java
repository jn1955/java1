package appl; 

public class Application {	
	
	public static void main(String[] args) {	
		demoDoWhile();
		demoSwitch();
		demoBreakAndContinue();
	}
	
	public static void demoDoWhile() {
		System.out.println("demoDoWhile");
		int counter = 0;
		do {
			System.out.println(counter);
			counter++;
		}
		while(counter < 5);  // Post-Check
	}

	public static void demoSwitch() {
        System.out.println("demoSwitch");
		int tag = 2;
		switch (tag) {
		case 0:
			System.out.println("Sonntag");
			break;
		case 1:
			System.out.println("Montag");
			break;
		case 2:
			System.out.println("Dienstag");
			break;
		case 3:
			System.out.println("Mittwoch");
			break;
		case 4:
			System.out.println("Donnerstag");
			break;
		case 5:
			System.out.println("Freitag");
			break;
		case 6:
			System.out.println("Samstag");
			break;
		default:
			System.out.println("falscher Tag...");
		}
		// Das k�nnte man mit arrays (hierzu sp�ter) besser machen...
	}
	
	public static void demoBreakAndContinue() {
		System.out.println("demoBreakAndContinue");
		int counter = 0;
		while (true) {
			counter++;
			if (counter % 2 == 0) {
				continue;
			}
			System.out.println(counter);
			if (counter > 5) {
				break;
			}
		}
	}
}
