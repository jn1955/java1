package appl;

import java.util.ArrayList;

import domain.Mitarbeiter;


public class Application {
	public static void main(String[] args) {
		
		Object obj = new Mitarbeiter(1000, "Meier");
		if (obj instanceof Mitarbeiter) {
			Mitarbeiter m = (Mitarbeiter) obj;
			m.print();
		}
		
		ArrayList<Object> objList = new ArrayList<>();
		objList.add(new Mitarbeiter(2000, "Mueller"));
		objList.add(new Mitarbeiter(3000, "Schulte"));
		objList.add("Hello World");  // Oh, Oh!!
		for (Object o : objList) {
			Mitarbeiter m = (Mitarbeiter) o;
			m.print();
		}
	}
}
