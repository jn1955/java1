package domain;

public class LohnempfaengerStatus extends MitarbeiterStatus {
	
	private double anzStd;
	private double stdLohn;

	public LohnempfaengerStatus(double anzStd, double stdLohn) {
		this.anzStd = anzStd ;
		this.stdLohn = stdLohn;
	}

	public final double getAnzStd() {
		return this.anzStd;
	}
	
	public final void setAnzStd(double anzStd) {
		this.anzStd = anzStd;
	}
	
	public final double getStdLohn() {
		return this.stdLohn;
	}
	
	public final void setStdLohn(double stdLohn) {
		this.stdLohn = stdLohn;
	}
	
	@Override
	public void print() {
		System.out.println(this.anzStd);
		System.out.println(this.stdLohn);
	}
	
	@Override
	public double getVerdienst() {
		return this.anzStd * this.stdLohn;
	}
}
