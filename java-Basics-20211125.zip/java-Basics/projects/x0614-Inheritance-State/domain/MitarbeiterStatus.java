package domain;

public abstract class MitarbeiterStatus {
	public abstract void print();
	public abstract double getVerdienst();
}
