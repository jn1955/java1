package appl;

import domain.Firma;
import domain.GehaltsempfaengerStatus;
import domain.LohnempfaengerStatus;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		Firma firma = new Firma("Siemens");
		firma.addMitarbeiter(new Mitarbeiter(1000, "Meier", new GehaltsempfaengerStatus(5000)));
		firma.addMitarbeiter(new Mitarbeiter(2000, "Mueller", new LohnempfaengerStatus(150, 20)));
		firma.addMitarbeiter(new Mitarbeiter(3000, "Schulte", new GehaltsempfaengerStatus(4000)));

		Mitarbeiter m = firma.findMitarbeiter(2000);
		m.setStatus(new GehaltsempfaengerStatus(6000));
		
		firma.print();
		System.out.println(firma.getGesamtVerdienst());
	}
}
