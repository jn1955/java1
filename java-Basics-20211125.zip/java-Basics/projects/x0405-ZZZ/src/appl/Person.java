package appl;

public class Person {
	public char sex;
	public String name;
	public Person partner;
}
