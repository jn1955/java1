package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		// TODO: statische print, init, heiraten, scheiden-Methoden in Person-Klasse 
		// einbauen und in der main-Methode nutzen 
		
	}
}
