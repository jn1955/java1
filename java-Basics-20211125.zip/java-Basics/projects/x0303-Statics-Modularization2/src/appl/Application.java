package appl;

public class Application {	
	
	public static void main(String[] args) {
		System.out.println(util.Math.ggt(77, 33));
		System.out.println(util.Math.kgv(77, 33));
		System.out.println(java.lang.Math.sqrt(2));
	}
	
}
