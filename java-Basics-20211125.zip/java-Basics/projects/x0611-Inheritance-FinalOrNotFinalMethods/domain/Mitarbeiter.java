package domain;

public abstract class Mitarbeiter {
	
	private final int nr;
	private String name;
	
	public Mitarbeiter(int nr, String name) {
		this.nr = nr;
		this.name = name;
	}
	
	public final int getNr() {
		return this.nr;
	}
	
	public final String getName() {
		return this.name;
	}
	
	public final void setName(String name) {
		this.name = name;
	}
	
	public void print() {
		System.out.println(this.nr);
		System.out.println(this.name);
	}
	
	public abstract double getVerdienst();
}
