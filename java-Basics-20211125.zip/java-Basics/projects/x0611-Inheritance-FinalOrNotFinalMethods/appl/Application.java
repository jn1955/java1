package appl;

import java.util.ArrayList;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		ArrayList<Mitarbeiter> liste = new ArrayList<>();

		liste.add(new Gehaltsempfaenger(1000, "Meier", 5000));
		liste.add(new Lohnempfaenger(2000, "Mueller", 150, 20));
		liste.add(new Gehaltsempfaenger(3000, "Schulte", 4000));

		for (Mitarbeiter m : liste) {
			System.out.println(m.getName());
		}
	}
}
