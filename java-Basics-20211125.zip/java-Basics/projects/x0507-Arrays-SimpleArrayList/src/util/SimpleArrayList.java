package util;

@SuppressWarnings("unchecked")
public class SimpleArrayList<E> {

	private E[] elements;
	private int elementCount;
	
	public SimpleArrayList(int capacity) {
		// this.elements = new E[capacity];
		this.elements = (E[])new Object[capacity];
	}
	public SimpleArrayList() {
		this(2);
	}
	public void add(E k) {
		if (this.elementCount == this.elements.length) {
			//E[] neueKonten = new E[this.elements.length * 2];
			E[] neueKonten = (E[])new Object[this.elements.length * 2];
			for (int i = 0; i < this.elements.length; i++) {
				neueKonten[i] = this.elements[i];
			}
			this.elements = neueKonten;
		}
		this.elements[this.elementCount] = k;
		this.elementCount++;
	}
	
	public int size() {
		return this.elementCount;
	}
	
	public E get(int index) {
		if (index < 0 || index >= this.elementCount) {
			throw new RuntimeException("illegal index");
		}
		return this.elements[index];
	}
}
