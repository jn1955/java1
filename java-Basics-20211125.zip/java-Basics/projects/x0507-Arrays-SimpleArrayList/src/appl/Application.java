package appl;

import java.util.ArrayList;

import util.SimpleArrayList;

public class Application {
	public static void main(String[] args) {
		demoSimpleArrayList();
		demoArrayList();
	}
	
	public static void demoSimpleArrayList() {
		System.out.println("demoSimpleArrayList");
		// SimpleArrayList<Konto> liste = new SimpleArrayList<Konto>();
		SimpleArrayList<Konto> liste = new SimpleArrayList<>();

		liste.add(new Konto(4711, 3000));
		liste.add(new Konto(4712, 4000));
		liste.add(new Konto(4713, 5000));
		liste.add(new Konto(4714, 6000));
		liste.add(new Konto(4715, 7000));

		for (int i = 0; i < liste.size(); i++) {
			Konto k = liste.get(i);
			k.print();
		}
	}

	public static void demoArrayList() {
		System.out.println("demoArrayList");
		ArrayList<Konto> liste = new ArrayList<>();

		liste.add(new Konto(4711, 3000));
		liste.add(new Konto(4712, 4000));
		liste.add(new Konto(4713, 5000));
		liste.add(new Konto(4714, 6000));
		liste.add(new Konto(4715, 7000));

		for (int i = 0; i < liste.size(); i++) {
			Konto k = liste.get(i);
			k.print();
		}
	}
}
