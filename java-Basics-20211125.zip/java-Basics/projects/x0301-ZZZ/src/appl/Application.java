package appl; 

public class Application {	
	
	public static void main(String[] args) {
		int alpha = 77;
		int beta = 33;

		// TODO... Call ggt-Method
		
		System.out.println("GGT = ");
	}
	
}
