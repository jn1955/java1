package appl;

import java.util.ArrayList;

public class Application {

	public static void main(String[] args) {

		demoIntWrapper();
		demoDoubleWrapper();
		demoAutoBoxing();
		demoListWithWrappers1();
		demoListWithWrappers2();
	}

	public static void demoIntWrapper() {
		System.out.println("demoIntWrapper");
		Integer wrapper1 = Integer.valueOf(1000);
		System.out.println(wrapper1);
		Object obj = wrapper1;
		Integer wrapper2 = (Integer) obj;
		int primitive = wrapper2.intValue();
		System.out.println(primitive);
	}

	public static void demoDoubleWrapper() {
		System.out.println("demoDoubleWrapper");
		Double wrapper1 = Double.valueOf(3.14);
		System.out.println(wrapper1);
		Object obj = wrapper1;
		Double wrapper2 = (Double) obj;
		double primitive = wrapper2.doubleValue();
		System.out.println(primitive);
	}

	public static void demoAutoBoxing() {
		System.out.println("demoAutoBoxing");
		int primitive1 = 4711;
		Integer wrapper = primitive1;
		int primitive2 = wrapper;
		System.out.println(primitive2);
	}

	public static void demoListWithWrappers1() {
		System.out.println("demoListWithWrappers1");
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.add(Integer.valueOf(10));
		numbers.add(Integer.valueOf(20));
		numbers.add(Integer.valueOf(30));
		int sum = 0;
		for (Integer wrapper : numbers) {
			int primitive = wrapper.intValue();
			sum += primitive;
		}
		System.out.println(sum);
	}

	public static void demoListWithWrappers2() {
		System.out.println("demoListWithWrappers2");
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.add(10);
		numbers.add(20);
		numbers.add(30);
		int sum = 0;
		for (Integer wrapper : numbers) {
			int primitive = wrapper;
			sum += primitive;
		}
		System.out.println(sum);
	}
}
