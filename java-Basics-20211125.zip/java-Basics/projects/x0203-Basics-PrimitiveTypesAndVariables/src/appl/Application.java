package appl;  
public class Application {	
	
	public static void main(String[] args) {	
		demoInt();
		demoByte();
		demoShort();
		demoLong();
		demoDouble();
		demoFloat();
		demoBoolean();
		demoChar();
		demoString();
	}
	
	public static void demoInt() {
		System.out.println("demoInt");
		int alpha;
		alpha = 42;
		int beta = 77;
		int gamma = (alpha + beta) * 2;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(Integer.MIN_VALUE);		// -2^31
		System.out.println(Integer.MAX_VALUE);  	// +2^31 -1
	}
	
	public static void demoByte() {
		System.out.println("demoByte");
		byte alpha = 42;
		byte beta = 77;
		byte gamma = (byte)((alpha + beta) * 2);
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(Byte.MIN_VALUE);			// -2^7
		System.out.println(Byte.MAX_VALUE);  		// +2^7 -1
	}
	public static void demoShort() {
		System.out.println("demoShort");
		short alpha = 42;
		short beta = 77;
		short gamma = (short)((alpha + beta) * 2);
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(Short.MIN_VALUE);		// -2^15
		System.out.println(Short.MAX_VALUE);  		// +2^15 -1
	}
	public static void demoLong() {
		System.out.println("demoLong");
		long alpha = 42;
		long beta = 77;
		long gamma = (alpha + beta) * 2;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(Long.MIN_VALUE);			// -2^63
		System.out.println(Long.MAX_VALUE);  		// +2^63 -1
	}
	public static void demoDouble() {
		System.out.println("demoDouble");
		double alpha = 3.14;
		double beta = 2.71;
		double gamma = (alpha + beta) * 2;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(Double.MIN_VALUE);		// 4.9E-324
		System.out.println(Double.MAX_VALUE);  		// 1.7976931348623157E308
	}
	public static void demoFloat() {
		System.out.println("demoFloat");
		float alpha = 3.14F;
		float beta = (float)2.71;
		float gamma = (alpha + beta) * 2;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(Float.MIN_VALUE);		// 1.4E-45
		System.out.println(Float.MAX_VALUE);  		// 3.4028235E38
	}
	public static void demoBoolean() {
		System.out.println("demoBoolean");
		boolean alpha = true;
		boolean beta = false;
		boolean gamma = alpha && beta;
		boolean delta = alpha || beta;
		boolean epsilon = ! alpha || ! beta;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(delta);
		System.out.println(epsilon);
	}
	public static void demoChar() {
		System.out.println("demoChar");
		char alpha = 'A';
		char beta = (char)65;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println((int)Character.MIN_VALUE);		// 0
		System.out.println((int)Character.MAX_VALUE);  		// +2^16 - 1
	}
	public static void demoString() {
		// String ist KEIN primitiver Typ - dazu sp�ter mehr...
		// Wir betrachten String zun�chst aber einfach als primitiven Typ
		System.out.println("demoString");
		String alpha = "";
		String beta = "A";
		String gamma = "BCDEF";
		String delta = beta + gamma;
		System.out.println(alpha);
		System.out.println(beta);
		System.out.println(gamma);
		System.out.println(delta);
	}	
}
