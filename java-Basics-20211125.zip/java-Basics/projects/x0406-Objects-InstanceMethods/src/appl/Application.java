package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		final Konto k1 = new Konto();
		k1.init(4711, 3000.0, 4000.0);
		k1.print();
		k1.einzahlen(500.0);
		k1.print();

		final Konto k2 = new Konto();
		k2.init(4712, 6000.0, 8000.0);
		k2.print();
		k2.auszahlen(500.0);
		k2.print();
	}
	
}
