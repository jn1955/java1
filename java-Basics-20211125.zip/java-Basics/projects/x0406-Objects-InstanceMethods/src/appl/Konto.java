package appl;

public class Konto { 
	public int nr;
	public double kredit;
	public double bestand;

	public void print(/* final Konto this */ ) {
		System.out.println(this.nr + " " + this.kredit + " " + this.bestand);
	}

	public void init(/* final Konto this, */ int nr, double kredit, double bestand) {
		this.nr = nr;
		this.kredit = kredit;
		this.bestand = bestand;
	}

	public void einzahlen(/* final Konto this, */ double betrag) {
		this.bestand += betrag;
	}

	public void auszahlen(/* final Konto this, */ double betrag) {
		this.bestand -= betrag;
	}

}
