package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		Konto k = new Konto(4711, 3000.0, 4000.0);
		k.print();
		try {
			k.auszahlen(10000.0);
			System.out.println("this will not be printed!");
		}
		catch(RuntimeException e) {
			System.out.println(e.getMessage());
		}
		k.auszahlen(7000.0);
		k.print();
	}
	
}
