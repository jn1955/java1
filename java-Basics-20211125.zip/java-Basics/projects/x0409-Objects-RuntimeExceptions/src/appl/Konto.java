package appl;

public class Konto { 
	public int nr;
	public double kredit;
	public double bestand;

	public Konto(int nr, double kredit, double bestand) {
		if (nr < 1000 || nr > 9999) {
			throw new RuntimeException("nr muss >= 1000 und <= 9999 sein");
		}
		if (kredit < 0) {
			throw new RuntimeException("kredit darf nicht negativ sein");
		}
		if (bestand < 0) {
			throw new RuntimeException("bestand darf nicht negativ sein");
		}
		this.nr = nr;
		this.kredit = kredit;
		this.bestand = bestand;
	}

	public Konto(int nr, double kredit) {
		this(nr, kredit, 0.0);
	}

	public Konto(int nr) {
		this(nr, 0.0);
	}

	public void print() {
		System.out.println(this.nr + " " + this.kredit + " " + this.bestand);
	}

	public void einzahlen(double betrag) {
		if (betrag < 0) {
			throw new RuntimeException("betrag darf nicht negativ sein");
		}
		this.bestand += betrag;
	}

	public void auszahlen(double betrag) {
		if (betrag < 0) {
			throw new RuntimeException("betrag darf nicht negativ sein");
		}
		if (betrag > this.bestand + this.kredit) {
			throw new RuntimeException("zu hoher betrag");
		}
		this.bestand -= betrag;
	}

}
