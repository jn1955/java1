package appl;

public class Kunde {
	public int nr;
	public String name;
	public Konto kto; // Pointer to Konto;
}
