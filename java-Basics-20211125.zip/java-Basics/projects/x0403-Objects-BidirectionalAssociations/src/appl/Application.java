package appl; 

public class Application {	
	
	public static void main(String[] args) {
		Kunde ku = new Kunde();
		ku.nr = 1000;
		ku.name = "Meier";
		
		Konto ko = new Konto();
		ko.nr = 4711;
		ko.kredit = 3000;
		ko.bestand = 4000;

		ko.kd = ku;
		ku.kto = ko;
		
		System.out.println(ko.kd);
		System.out.println(ko.kd.nr);
		System.out.println(ko.kd.name);
		
		System.out.println(ko.kd.kto);
		System.out.println(ko.kd.kto.nr);
		System.out.println(ko.kd.kto.kd.kto.kredit);
		System.out.println(ko.kd.kto.kd.kto.kd.kto.bestand);
	}
}
