package appl;

import java.util.ArrayList;

import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

public class Application {
	public static void main(String[] args) {
		
		ArrayList<Mitarbeiter> liste = new ArrayList<>();

		liste.add(new Mitarbeiter(1000, "Meier"));
		liste.add(new Lohnempfaenger(2000, "Mueller", 150, 20));
		liste.add(new Gehaltsempfaenger(3000, "Schulte", 4000));

		for (Mitarbeiter m : liste) {
			System.out.println(m.nr);
			System.out.println(m.name);
			if (m instanceof Lohnempfaenger) {
				Lohnempfaenger l = (Lohnempfaenger) m;
				System.out.println(l.anzStd);
				System.out.println(l.stdLohn);
			}
			else if (m instanceof Gehaltsempfaenger) {
				Gehaltsempfaenger g = (Gehaltsempfaenger) m;
				System.out.println(g.gehalt);
			}
			System.out.println();
		}

		double gesamtVerdienst = 0;
		for (Mitarbeiter m : liste) {
			if (m instanceof Lohnempfaenger) {
				Lohnempfaenger l = (Lohnempfaenger) m;
				gesamtVerdienst += l.anzStd * l.stdLohn;
			}
			else if (m instanceof Gehaltsempfaenger) {
				Gehaltsempfaenger g = (Gehaltsempfaenger) m;
				gesamtVerdienst += g.gehalt;
			}
		}
		System.out.println("Total = " + gesamtVerdienst);
	}
}
