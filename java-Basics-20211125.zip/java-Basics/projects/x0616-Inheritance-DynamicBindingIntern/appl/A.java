package appl;

public class A {
	public void f() {
		System.out.println("A:f");
	}
	public void g() {
		System.out.println("A:g");
	}
	public void h() {
		System.out.println("A:h");
	}
}
