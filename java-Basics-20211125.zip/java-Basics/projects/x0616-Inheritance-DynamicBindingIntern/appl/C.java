package appl;

public class C extends A {
	@Override
	public void f() {
		System.out.println("C:f");
	}
	public void y() {
		System.out.println("C:y");
	}
}
