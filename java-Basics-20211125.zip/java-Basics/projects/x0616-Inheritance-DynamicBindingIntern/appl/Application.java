package appl;

public class Application {
	public static void main(String[] args) {
		A a1 = new B();
		A a2 = new C();
		a1.f();
		a2.f();
		a1.g();
		a2.g();
		a1.h();
		a2.h();
	}
}
