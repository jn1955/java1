package appl;

public class B extends A {
	public void x() {
		System.out.println("B:x");
	}
	@Override
	public void g() {
		System.out.println("B:g");
	}
}
