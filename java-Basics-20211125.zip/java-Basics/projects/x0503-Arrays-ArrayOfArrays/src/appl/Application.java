package appl;

public class Application {
	public static void main(String[] args) {
		demo1();
		demo2();
		demo3();
		demo4();
	}

	public static void demo1() {
		System.out.println("demo1");
		int[][] m = new int[2][];
		for (int i = 0; i < m.length; i++)
			m[i] = new int[3];
		m[0][0] = 10;
		m[0][1] = 20;
		m[0][2] = 30;
		m[1][0] = 90;
		m[1][1] = 80;
		m[1][2] = 70;

		printA(m);
		printB(m);
		printC(m);
	}

	public static void demo2() {
		System.out.println("demo2");
		int[][] m = new int[2][3];
		m[0][0] = 10;
		m[0][1] = 20;
		m[0][2] = 30;
		m[1][0] = 90;
		m[1][1] = 80;
		m[1][2] = 70;

		printA(m);
		printB(m);
		printC(m);
	}

	public static void demo3() {
		System.out.println("demo3");
		int[][] m = new int[][] { { 10, 20, 30 }, { 90, 80, 70 } };
		printA(m);
		printB(m);
		printC(m);
	}

	public static void demo4() {
		System.out.println("demo4");
		int[][] m = new int[][] { { 10, 20, 30 }, { 90, 80 }, { 50 } };
		printA(m);
		printB(m);
		printC(m);
	}

	private static void printA(int[][] matrix) {
		for (int y = 0; y < matrix.length; y++) {
			int[] row = matrix[y];
			for (int x = 0; x < row.length; x++) {
				System.out.print(row[x] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

	private static void printB(int[][] matrix) {
		for (int y = 0; y < matrix.length; y++) {
			for (int x = 0; x < matrix[y].length; x++) {
				System.out.print(matrix[y][x] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

	private static void printC(int[][] matrix) {
		for (int[] row : matrix) {
			for (int value : row) {
				System.out.print(value + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

}
