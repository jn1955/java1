package domain;

public class Lohnempfaenger extends Mitarbeiter {
	
	private double anzStd;
	private double stdLohn;

	public Lohnempfaenger(int nr, String name, double anzStd, double stdLohn) {
		super(nr, name);
		this.anzStd = anzStd ;
		this.stdLohn = stdLohn;
	}

	public double getAnzStd() {
		return this.anzStd;
	}
	
	public void setAnzStd(double anzStd) {
		this.anzStd = anzStd;
	}
	
	public double getStdLohn() {
		return this.stdLohn;
	}
	
	public void setStdLohn(double stdLohn) {
		this.stdLohn = stdLohn;
	}
	
	@Override
	public void print() {
		this.printBase();
		System.out.println(this.anzStd);
		System.out.println(this.stdLohn);
	}
	
	@Override
	public double getVerdienst() {
		return this.anzStd * this.stdLohn;
	}
}
