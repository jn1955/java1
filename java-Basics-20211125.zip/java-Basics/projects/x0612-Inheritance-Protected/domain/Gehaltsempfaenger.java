package domain;

public class Gehaltsempfaenger extends Mitarbeiter {
	
	private double gehalt;

	public Gehaltsempfaenger(int nr, String name, double gehalt) {
		super(nr, name);
		this.gehalt = gehalt;
	}

	public final double getGehalt() {
		return this.gehalt;
	}
	
	public final void setGehalt(double gehalt) {
		this.gehalt = gehalt;
	}

	@Override
	public void print() {
		this.printBase();
		System.out.println(this.gehalt);
	}
	
	@Override
	public double getVerdienst() {
		return this.gehalt;
	}
}
