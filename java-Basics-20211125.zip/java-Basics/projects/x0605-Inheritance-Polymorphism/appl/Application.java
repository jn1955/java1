package appl;

import util.Console;
import domain.Gehaltsempfaenger;
import domain.Lohnempfaenger;
import domain.Mitarbeiter;

@SuppressWarnings("unused")

public class Application {
	public static void main(String[] args) {
		
		Mitarbeiter ma = new Mitarbeiter(1000, "Meier");
		Lohnempfaenger le = new Lohnempfaenger(2000, "Mueller", 150, 20);
		Gehaltsempfaenger ge = new Gehaltsempfaenger(3000, "Schulte", 4000);

		Mitarbeiter m;
		
		m = ma;
		System.out.println(m.nr);
		System.out.println(m.name);
		System.out.println();
		
		m = le;
		System.out.println(m.nr);
		System.out.println(m.name);
		//System.out.println(m.anzStd);  // illegal
		//System.out.println(m.stdLohn); // illegal
		System.out.println();

		m = ge;
		System.out.println(m.nr);
		System.out.println(m.name);
		// System.out.println(m.gehalt); // illegal
		System.out.println();
		
		int x = Console.readInt("Bitte 1 oder 2 eingeben:");
		
		if (x == 1) {
			m = new Gehaltsempfaenger(4000, "Nowak", 5000);
		}
		else {
			m = new Lohnempfaenger(5000, "Rueschenpoehler", 2000, 40);
		}
		// worauf zeigt jetzt m? Der Compiler kann's nicht wissen!
		System.out.println(m.nr);
		System.out.println(m.name);
		// und mehr geht dann auch nicht...
		
		Lohnempfaenger l;
		// l = ma; // illegal!
		Gehaltsempfaenger g;
		// g = ma; // illegal!
			
	}
}
