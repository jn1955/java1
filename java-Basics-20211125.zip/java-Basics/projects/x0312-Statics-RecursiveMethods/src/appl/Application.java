package appl; 

public class Application {	
	
	public static void main(String[] args) {
		print(5);
		System.out.println(fakultaet(5));
	}
	
	public static void print(int n) {
		if (n < 0)
			return;
		System.out.println(n);
		print(n - 1);
	}
	
	public static int fakultaet(int n) {
		if (n == 0)
			return 1;
		return n * fakultaet(n - 1);
	}

}
