package domain;

public class Lohnempfaenger extends Mitarbeiter {
	public double anzStd;
	public double stdLohn;
}
