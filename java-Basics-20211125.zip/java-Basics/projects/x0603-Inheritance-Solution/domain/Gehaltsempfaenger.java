package domain;

public class Gehaltsempfaenger extends Mitarbeiter {
	public double gehalt;
}
