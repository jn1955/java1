package appl;

public class Application {
	public static void main(String[] args) {
		
		// TODO: implement the Methods 
		
		demoUpperLowerCase();
		demoLengthAndCharAt();
		demoContains();
	}

	public static void demoUpperLowerCase() {
		System.out.println("demoUpperLowerCase");
	}

	public static void demoLengthAndCharAt() {
		System.out.println("demoLengthAndCharAt");
	}

	public static void demoContains() {
		System.out.println("demoContains");
	}
}
