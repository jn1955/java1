package appl;  // appl ist ein Unterverzeichnis des src- und bin-Ordners des Projekts 

/*
 * Meine erste Application
 * Ausgabe von "Hello World"
 */

public class Application {	// Application.java ist eine Datei im src/appl-Verzeichnis des Projekts
	
	public static void main(String[] args) {	// �berschrift des Hauptprogramms
		System.out.println("Hello World");   
	}
}
