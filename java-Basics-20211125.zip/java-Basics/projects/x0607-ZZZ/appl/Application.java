package appl;

public class Application {
	public static void main(String[] args) {
		
		// TODO
		// Speichern Sie Figuren unterschiedlichen Typs in einer einzigen ArrayList
	}
}
