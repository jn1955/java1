package appl;


public class Application {
	public static void main(String[] args) {
		Thermostat t = new Thermostat();
		t.add(new Heizung());
		t.add(new Heizung());
		t.run();
	}
}
