package appl;

import java.util.ArrayList;

public class Thermostat {
	private ArrayList<ThermostatListener> listeners = new ArrayList<>();
	
	public void add(ThermostatListener listener) {
		this.listeners.add(listener);
	}
	
	public void run() {
		// es ist zu kalt geworden...
		for (ThermostatListener listener : this.listeners)
			listener.minAlarm();
		// es ist zu warm geworden...
		for (ThermostatListener listener : this.listeners)
			listener.maxAlarm();
	}
}
