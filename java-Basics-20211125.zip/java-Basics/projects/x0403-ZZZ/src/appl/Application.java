package appl; 

public class Application {	
	
	public static void main(String[] args) {
		
		// erzeugen und initialisieren zweier Personen p1: ('m', "Meier"), p2: ('w', "Mueller")
		
		// Ausgabe der ersten Person (==> m Meier unverheiratet
		
		// Verheiratung der beiden
		
		// Ausgabe der ersten Person (==> m Meier Mueller
		
		// p2 = null;
		// Scheidung der beiden
		
		// Ausgabe der ersten Person (==> m Meier unverheiratet
	}
}
