package appl;

public class Person {
	// TODO: sex, name, partner
}
